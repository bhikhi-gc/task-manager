import React from 'react';


const User = () => {
	return(
		<h1>User</h1>
	)
}

export default User;